# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin CLK_OUT ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN_N ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin SA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON_N ignore
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{CLK_IN rise} {CLK1 rise} {CLK2 rise} {CLK3 rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin CLK_OUT ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN_N ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin SA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON_N ignore
# Skew Group: CLK1/cm
create_ccopt_skew_group -name CLK1/cm -from_clocks {CLK1} -from_constraint_modes {cm} -from_delay_corners {dc_tt dc_tt} -auto_sinks -sources {CLK1}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: CLK2/cm
create_ccopt_skew_group -name CLK2/cm -from_clocks {CLK2} -from_constraint_modes {cm} -from_delay_corners {dc_tt dc_tt} -auto_sinks -sources {CLK2}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: CLK3/cm
create_ccopt_skew_group -name CLK3/cm -from_clocks {CLK3} -from_constraint_modes {cm} -from_delay_corners {dc_tt dc_tt} -auto_sinks -sources {CLK3}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: CLK_IN/cm
create_ccopt_skew_group -name CLK_IN/cm -from_clocks {CLK_IN} -from_constraint_modes {cm} -from_delay_corners {dc_tt dc_tt} -auto_sinks -sources {CLK_IN}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin CLK_OUT ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN_N ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin SA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON_N ignore
# Skew Group: 01
create_ccopt_skew_group -name 01 -generated  -fragment  -target_skew 0.000 -sinks {CLK_OUT} -rank 0 -sources {{CLK_IN rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 01 -add_ignore_pins {CLK_OUT}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 03
create_ccopt_skew_group -name 03 -generated  -fragment  -target_skew 0.000 -sinks {g2762__8757/Y} -rank 0 -sources {{CLK3 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 03 -add_ignore_pins {g2762__8757/Y g2762__8757/B}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 04
create_ccopt_skew_group -name 04 -generated  -fragment  -target_skew 0.000 -sinks {g2760__7675/Y} -rank 0 -sources {{CLK3 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 04 -add_ignore_pins {g2760__7675/Y g2760__7675/B g2760__7675/D}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 06
create_ccopt_skew_group -name 06 -generated  -fragment  -target_skew 0.000 -sinks {g2762__8757/Y} -rank 0 -sources {{CLK2 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 06 -add_ignore_pins {g2762__8757/A g2762__8757/Y}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 07
create_ccopt_skew_group -name 07 -generated  -fragment  -target_skew 0.000 -sinks {g2761__7118/Y} -rank 0 -sources {{CLK2 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 07 -add_ignore_pins {g2761__7118/Y g2761__7118/B}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 08
create_ccopt_skew_group -name 08 -generated  -fragment  -target_skew 0.000 -sinks {g2760__7675/Y} -rank 0 -sources {{CLK2 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 08 -add_ignore_pins {g2760__7675/A g2760__7675/Y g2760__7675/D}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 10
create_ccopt_skew_group -name 10 -generated  -fragment  -target_insertion_delay 0.107 -target_skew 0.004 -sinks {{dat_reg[0]/CK} {state_reg[0]/CK} {dat_reg[4]/CK} {cn_reg_reg[0]/CK} {state_reg[1]/CK} {dat_reg[1]/CK} {dat_reg[2]/CK} {dat_reg[3]/CK} {dat_reg[5]/CK} {dat_reg[7]/CK} {dat_reg[6]/CK} {cn_reg_reg[4]/CK} cnc_reg_reg/CK eoc_reg_reg/CK {state_reg[2]/CK} {state_reg[3]/CK} {b_reg_reg[7]/CK} {b_reg_reg[3]/CK} {b_reg_reg[6]/CK} {b_reg_reg[1]/CK} {b_reg_reg[0]/CK} {b_reg_reg[4]/CK} {b_reg_reg[2]/CK} {cp_reg_reg[7]/CK} {b_reg_reg[5]/CK} {cp_reg_reg[3]/CK} {cn_reg_reg[5]/CK} {cn_reg_reg[6]/CK} {cp_reg_reg[1]/CK} {cp_reg_reg[6]/CK} {cp_reg_reg[5]/CK} {cn_reg_reg[7]/CK} {cp_reg_reg[2]/CK} {cn_reg_reg[1]/CK} {cn_reg_reg[3]/CK} {cp_reg_reg[0]/CK} {cp_reg_reg[4]/CK} {cn_reg_reg[2]/CK}} -rank 0 -sources {{CLK1 rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 11
create_ccopt_skew_group -name 11 -generated  -fragment  -target_skew 0.000 -sinks {g2759__2391/Y} -rank 0 -sources {{CLK1 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 11 -add_ignore_pins {g2759__2391/A1 g2759__2391/Y}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 12
create_ccopt_skew_group -name 12 -generated  -fragment  -target_skew 0.000 -sinks {g2761__7118/Y} -rank 0 -sources {{CLK1 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 12 -add_ignore_pins {g2761__7118/A g2761__7118/Y}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 13
create_ccopt_skew_group -name 13 -generated  -fragment  -target_skew 0.000 -sinks {g2760__7675/Y} -rank 0 -sources {{CLK1 rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 13 -add_ignore_pins {g2760__7675/A g2760__7675/Y g2760__7675/B}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 14
create_ccopt_skew_group -name 14 -generated  -fragment  -target_skew 0.000 -sinks {g2759__2391/Y} -rank 0 -sources {{g2762__8757/Y rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 14 -add_ignore_pins {g2759__2391/Y g2759__2391/A0}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 15
create_ccopt_skew_group -name 15 -generated  -fragment  -target_skew 0.000 -sinks {VCM_CON VCM_CON_N} -rank 0 -sources {{g2759__2391/Y rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 15 -add_ignore_pins {VCM_CON VCM_CON_N}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 16
create_ccopt_skew_group -name 16 -generated  -fragment  -target_skew 0.000 -sinks {PA_EN PA_EN_N} -rank 0 -sources {{g2761__7118/Y rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 16 -add_ignore_pins {PA_EN PA_EN_N}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: 17
create_ccopt_skew_group -name 17 -generated  -fragment  -target_skew 0.000 -sinks {SA_EN} -rank 0 -sources {{g2760__7675/Y rise}}
#
# modifying the skew group to add ignore pins
modify_ccopt_skew_group -skew_group 17 -add_ignore_pins {SA_EN}
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin CLK_OUT ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin PA_EN_N ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin SA_EN ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON ignore
set_ccopt_property insertion_delay -delay_corner dc_tt -late -rise -pin VCM_CON_N ignore
# Skew Group: CLK1/cm
create_ccopt_skew_group -name CLK1/cm -auto_sinks -sources {CLK1}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: CLK2/cm
create_ccopt_skew_group -name CLK2/cm -auto_sinks -sources {CLK2}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: CLK3/cm
create_ccopt_skew_group -name CLK3/cm -auto_sinks -sources {CLK3}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: CLK_IN/cm
create_ccopt_skew_group -name CLK_IN/cm -auto_sinks -sources {CLK_IN}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{CLK_IN rise} {CLK1 rise} {CLK2 rise} {CLK3 rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default