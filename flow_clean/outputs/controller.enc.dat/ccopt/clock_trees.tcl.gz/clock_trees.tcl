# ccopt saved state clock_trees.tcl.gz

create_ccopt_clock_tree -name CLK_IN -source CLK_IN -no_skew_group 
create_ccopt_clock_tree -name CLK3 -source CLK3 -no_skew_group 
create_ccopt_clock_tree -name CLK2 -source CLK2 -no_skew_group 
create_ccopt_clock_tree -name CLK1 -source CLK1 -no_skew_group 
